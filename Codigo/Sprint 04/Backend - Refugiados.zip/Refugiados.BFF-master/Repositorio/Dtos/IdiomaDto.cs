﻿namespace Repositorio.Dtos
{
    public class IdiomaDto
    {
        public int codigo_idioma { get; set; }
        public string nome_idioma { get; set; }
    }
}

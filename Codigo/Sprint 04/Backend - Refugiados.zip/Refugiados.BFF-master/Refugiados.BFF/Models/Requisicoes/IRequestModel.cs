﻿namespace Refugiados.BFF.Models.Requisicoes
{
    interface IRequestModel
    {
        public ValidacaoRequisicaoModel Validar();
    }
}

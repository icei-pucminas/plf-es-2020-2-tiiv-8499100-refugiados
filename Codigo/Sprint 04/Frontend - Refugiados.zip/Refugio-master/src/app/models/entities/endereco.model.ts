export class Endereco {
	cepEndereco: string;
	complementoEndereco: string;
	ruaEndereco: string;
	cidadeEndereco: string;
	bairroEndereco: string;
	estadoEndereco: string;
	numeroEndereco: string;
}

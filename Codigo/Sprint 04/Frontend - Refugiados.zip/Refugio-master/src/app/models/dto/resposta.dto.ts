export default class RespostaDTO {
	public statusCode: number;
	public sucesso: boolean;
	public mensagem: string;
	public corpo: any;
}

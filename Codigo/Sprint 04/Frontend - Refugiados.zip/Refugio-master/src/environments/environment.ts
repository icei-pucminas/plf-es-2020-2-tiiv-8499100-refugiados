// DEVELOP ENVIROMENT
export const environment = {
  production: false,
  API_BASEPATH: 'https://refugiados.herokuapp.com',
};

// PRODUCTION ENVIROMENT
export const environment = {
  production: true,
  API_BASEPATH: 'https://refugiados.herokuapp.com',
};

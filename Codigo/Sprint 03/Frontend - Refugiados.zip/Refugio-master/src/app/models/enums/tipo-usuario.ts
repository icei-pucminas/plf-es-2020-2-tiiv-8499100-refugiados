export enum TipoUsuario {
	ADMIN = null,
	EMPRESA = 1,
	COLABORADOR = 2,
}

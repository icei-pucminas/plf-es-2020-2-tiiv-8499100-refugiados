export class Empresa {
	codigoEmpresa: number;
	codigoUsuario: number;
	emailContato: string;
	razaoSocial: string;
	dataCriacao: Date;
	dataAlteracao: Date;
}

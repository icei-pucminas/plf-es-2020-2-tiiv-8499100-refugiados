export class Colaborador {
	codigoColaborador: number;
	codigoUsuario: number;
	emailContato: string;
	nomeColaborador: string;
	dataCriacao: Date;
	dataAlteracao: Date;
}

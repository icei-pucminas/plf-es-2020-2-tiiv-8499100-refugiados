export class Usuario {
  nome: string;
  email: string;
  senha: string;
}

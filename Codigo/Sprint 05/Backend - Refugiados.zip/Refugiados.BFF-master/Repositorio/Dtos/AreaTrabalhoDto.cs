﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Repositorio.Dtos
{
    public class AreaTrabalhoDto
    {
        public int codigo_area_trabalho { get; set; }
        public string nome_area_trabalho { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Refugiados.BFF.Models
{
    public class AreaTrabalhoModel
    {
        public int CodigoAreaTrabalho { get; set; }
        public string DescricaoAreaTrabalho { get; set; }
    }
}

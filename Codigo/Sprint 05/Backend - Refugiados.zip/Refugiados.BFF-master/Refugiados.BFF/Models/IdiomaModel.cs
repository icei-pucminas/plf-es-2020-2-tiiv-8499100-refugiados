﻿namespace Refugiados.BFF.Models
{
    public class IdiomaModel
    {
        public int CodigoIdioma { get; set; }
        public string DescricaoIdioma { get; set; }
    }
}

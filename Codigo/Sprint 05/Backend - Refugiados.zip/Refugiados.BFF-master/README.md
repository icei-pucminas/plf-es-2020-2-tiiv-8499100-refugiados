# Refugiados.BFF
API em ASP.Net core para disciplina Trabalho interdisciplinar de Software 4 do curso engenharia de software

Participantes do projeto:
Tomás Campos
William Menegaldi
Jonathan David
João Marcos
Lucca Bessa

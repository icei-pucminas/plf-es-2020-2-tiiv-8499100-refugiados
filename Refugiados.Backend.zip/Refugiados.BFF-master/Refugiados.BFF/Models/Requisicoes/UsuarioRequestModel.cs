﻿namespace Refugiados.BFF.Models.Requisicoes
{
    public class UsuarioRequestModel
    {
        public string EmailUsuario { get; set; }
        public string SenhaUsuario { get; set; }
    }
}

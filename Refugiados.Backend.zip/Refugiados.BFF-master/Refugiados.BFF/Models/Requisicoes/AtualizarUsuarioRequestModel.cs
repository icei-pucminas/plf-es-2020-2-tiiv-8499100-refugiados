﻿namespace Refugiados.BFF.Models.Requisicoes
{
    public class AtualizarUsuarioRequestModel : UsuarioRequestModel
    {
        public int CodigoUsuario { get; set; }
    }
}
